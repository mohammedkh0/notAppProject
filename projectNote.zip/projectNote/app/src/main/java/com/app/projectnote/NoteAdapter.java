package com.app.projectnote;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class NoteAdapter extends FirestoreRecyclerAdapter<Notes , NoteAdapter.ViewHolderNote> {

    Context context;

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public NoteAdapter(@NonNull FirestoreRecyclerOptions<Notes> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolderNote holder, int position, @NonNull Notes model) {
        holder.title.setText(model.title);
        holder.content.setText(model.content);
        holder.timestamp.setText(Utils.timestampToString(model.timestamp));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, AddNewNoteScreen.class);
                i.putExtra("title" , model.title);
                i.putExtra("content" , model.content);
                String NoteID = getSnapshots().getSnapshot(holder.getAdapterPosition()).getId();
                i.putExtra("NoteID" , NoteID);
                context.startActivity(i);
            }
        });
    }

    @NonNull
    @Override
    public ViewHolderNote onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_item, parent, false);
        return new ViewHolderNote(view);
    }

    class  ViewHolderNote extends RecyclerView.ViewHolder{
        TextView title , content, timestamp ;
        public ViewHolderNote(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title_note);
            content = itemView.findViewById(R.id.content_note);
            timestamp = itemView.findViewById(R.id.time_note);
        }
    }
}
