package com.app.projectnote;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpScreen extends AppCompatActivity {
    EditText editText_email,editText_pass,editText_conf_pass;
    Button createAccount;
    ProgressBar progressBar;
    TextView login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_screen);
        editText_email = findViewById(R.id.email_edit_text);
        editText_pass = findViewById(R.id.pass);
        editText_conf_pass = findViewById(R.id.confirm_pass);
        createAccount = findViewById(R.id.create_account_btn);
        progressBar = findViewById(R.id.progress_bar);
        login = findViewById(R.id.login_text_view_btn);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignUp();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUpScreen.this , LoginScreen.class));
                finish();
            }
        });
    }
    void SignUp(){
        String email = editText_email.getText().toString();
        String password = editText_pass.getText().toString();
        String confirmPassword = editText_conf_pass.getText().toString();

        boolean validate = Validate(email,password,confirmPassword);

        if (!validate){
            return;
        }
        SignUpFirebase(email,password);
    }
    boolean Validate(String email ,String password ,String confirmPassword){
        if (email.isEmpty()){
            editText_email.setError("Email has required!");
        }
        if (password.length() < 6){
            editText_pass.setError("Password length should be 6 char!");
            return false;
        }
        if (!password.equals(confirmPassword)){
            editText_conf_pass.setError("Password not matched!");
            return false;
        }

        return true;
    }

    void SignUpFirebase(String email, String password){
        IsProgress(true);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                IsProgress(false);
                if (task.isSuccessful()){
                    Toast.makeText(SignUpScreen.this, "SignUp Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignUpScreen.this,LoginScreen.class));
                    finish();
                }else {
                    Toast.makeText(SignUpScreen.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    void IsProgress (boolean prog){
        if (prog){
            progressBar.setVisibility(View.VISIBLE);
            createAccount.setVisibility(View.GONE);
        }else {
            progressBar.setVisibility(View.GONE);
            createAccount.setVisibility(View.VISIBLE);
        }
    }
}