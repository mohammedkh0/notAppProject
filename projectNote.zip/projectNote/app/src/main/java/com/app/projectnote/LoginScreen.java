package com.app.projectnote;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginScreen extends AppCompatActivity {



    EditText email , password;
    Button loginAccount;
    ProgressBar progressBar;
    TextView signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        signUp = findViewById(R.id.signUp_text_view_btn);
        loginAccount = findViewById(R.id.login_btn);
        progressBar = findViewById(R.id.progress_bar_login);
        email = findViewById(R.id.email_edit_text_login);
        password = findViewById(R.id.pass_login);

        loginAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginScreen.this , SignUpScreen.class));
                finish();
            }
        });
    }
    void login(){
        String emailLogin = email.getText().toString();
        String passwordLogin = password.getText().toString();


        boolean validate = Validate(emailLogin,passwordLogin);

        if (!validate){
            return;
        }
        LoginFirebase(emailLogin,passwordLogin);
    }
    boolean Validate(String emailLogin ,String passwordLogin) {
        if (emailLogin.isEmpty()||passwordLogin.isEmpty()){
            Toast.makeText(this, "All field are required!", Toast.LENGTH_SHORT).show();
        }
        if (passwordLogin.length() < 6){
            password.setError("Password length should be 6 char!");
            return false;
        }
        return true;
    }

    void LoginFirebase(String email, String password){
        IsProgress(true);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                IsProgress(false);
                if (task.isSuccessful()){
                    Toast.makeText(LoginScreen.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginScreen.this, MainActivity.class));
                    finish();
                }else {
                    Toast.makeText(LoginScreen.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    System.out.println( task.getException().getLocalizedMessage());
                }
            }
        });
    }
    void IsProgress (boolean prog){
        if (prog){
            progressBar.setVisibility(View.VISIBLE);
            loginAccount.setVisibility(View.GONE);
        }else {
            progressBar.setVisibility(View.GONE);
            loginAccount.setVisibility(View.VISIBLE);
        }
    }
}