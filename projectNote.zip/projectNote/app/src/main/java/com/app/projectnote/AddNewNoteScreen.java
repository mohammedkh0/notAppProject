package com.app.projectnote;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;

public class AddNewNoteScreen extends AppCompatActivity {
    ImageButton add;
    EditText titleNote, contentNote;
    TextView titlePage, deleteNote;
    String title, content, id;

    LinearLayout deletedContainer;

    boolean isEdite = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_note_screen);
        add = findViewById(R.id.add_note);
        titleNote = findViewById(R.id.title_note);
        contentNote = findViewById(R.id.content_note);
        titlePage = findViewById(R.id.title_page);
        deleteNote = findViewById(R.id.delete_note);
        deletedContainer = findViewById(R.id.deleted_container);

        title = getIntent().getStringExtra("title");
        content = getIntent().getStringExtra("content");
        id = getIntent().getStringExtra("NoteID");


        if (id != null && !id.isEmpty()){
             isEdite = true;
        }
        if (title != null && !title.isEmpty()){
            titleNote.setText(title);
        }
        if (content != null && !content.isEmpty()){
            contentNote.setText(content);
        }
        if (isEdite){
            titlePage.setText("Edite Your Note");
            deletedContainer.setVisibility(View.VISIBLE);
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SaveNote();
            }
        });
        deleteNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteFormFirebase();
            }
        });
    }

     void deleteFormFirebase() {
         DocumentReference documentReference;
             documentReference = Utils.collectionReferenceForNote().document(id);

         documentReference.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
             @Override
             public void onComplete(@NonNull Task<Void> task) {
                 if (task.isSuccessful()){
                     Toast.makeText(AddNewNoteScreen.this, "The note deleted success", Toast.LENGTH_SHORT).show();
                     finish();
                 }else {
                     Toast.makeText(AddNewNoteScreen.this, "Error in delete note!!", Toast.LENGTH_SHORT).show();

                 }

             }
         });
    }

    void SaveNote() {
        String title = titleNote.getText().toString();
        String content = contentNote.getText().toString();

        if (title == null || title.isEmpty()) {
            titleNote.setError("The Title is required!!");
            return;
        }
        Notes note = new Notes();
        note.setContent(content);
        note.setTitle(title);
        note.setTimestamp(Timestamp.now());

        SaveNoteFirebase(note);
    }

    void SaveNoteFirebase(Notes note){
        DocumentReference documentReference;
        if (isEdite){
            documentReference = Utils.collectionReferenceForNote().document(id);
        }else {
            documentReference = Utils.collectionReferenceForNote().document();
        }
        documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Toast.makeText(AddNewNoteScreen.this, "The note add success", Toast.LENGTH_SHORT).show();
                    finish();
                }else {
                    Toast.makeText(AddNewNoteScreen.this, "Error in add note!!", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}